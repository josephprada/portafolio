<?php
/**
 * Testimonials wrap end template
 */
?></div>
